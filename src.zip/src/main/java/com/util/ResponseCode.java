package com.util;

/**
 * @author xuhongnan
 * 创建时间 2019-7-16
 */
public enum ResponseCode {
    //成功
    OK,
    //失败 通用错误
    ERROR,
}
