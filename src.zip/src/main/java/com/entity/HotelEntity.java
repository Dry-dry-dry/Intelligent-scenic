package com.entity;

import lombok.Data;

@Data
public class HotelEntity {
    private int id;
    private String hotelname;
    private String position;
    private String phone;
    private int roomnum;
    private int roomprice;

}
